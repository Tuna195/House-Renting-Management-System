Không gian làm việc của nhóm cho bài tập lớn **Hệ thống quản lý vận hành và tính phí nhà cho thuê**. Code nằm trên GitHub, còn **kế hoạch, phân công và hướng dẫn nằm ở đây**.

🗺️ **Lộ trình 12 tuần trên một màn hình:** https://claude.ai/artifact/BFbqWkHoASwyD4AsYBQ6Aj (bấm vào từng ô để xem kết quả cần đạt và việc phải xong trước)

## Cách dùng Notion trong nhóm
- **Tick checklist** ngay trong trang tuần khi xong việc, cả nhóm thấy ngay
- Gõ `@` rồi tên trang để **dẫn link** sang trang khác; gõ `@` rồi tên bạn để **gọi tên** (bạn đó nhận thông báo)
- Bôi đen một đoạn → **Comment** để hỏi hoặc góp ý, đừng sửa thẳng nội dung của người khác
- **Không dán** mật khẩu, chuỗi kết nối database, khóa bí mật vào Notion

## Tuần đầu tiên, ai cũng phải đọc
1. `README.md` **trong repo code**: cài đặt và chạy project
2. **01 Phân công vai trò**: mình là TV mấy, phụ trách gì
3. **Kế hoạch 12 tuần → 00 Tổng quan kế hoạch**: các mốc, quy tắc làm việc
4. **Kế hoạch 12 tuần → Tuần 01**: việc cụ thể của tuần này
5. `CONVENTIONS.md` **trong repo code**: quy ước code
6. **06 Quy trình Git**
7. **07 Dùng AI hiệu quả**

## Tài liệu thiết kế (hoàn thiện ở Tuần 2, cập nhật dần)
| Trang | Nội dung | Người giữ |
|---|---|---|
| **02 Yêu cầu chức năng** | Danh sách chức năng theo mức ưu tiên | TV1 |
| **03 Công thức tính tiền** | Quy tắc tính tiền và ví dụ tính tay | TV3 |
| **04 Thiết kế database** | Sơ đồ ERD, giải thích các bảng | TV2 |
| **05 Danh sách API** | API, người làm, trạng thái | TV2 |

## Cuối kỳ
- **08 Vấn đáp và báo cáo**: bộ câu hỏi vấn đáp, dàn ý báo cáo
- **09 Mẫu biên bản họp**: mẫu ghi biên bản họp tuần

## Các trang nhóm sẽ tạo thêm trong quá trình làm
| Trang | Tuần | Người tạo |
|---|---|---|
| Biên bản họp (mỗi tuần một trang con) | 1–12 | TV1 |
| Biên bản khảo sát | 2 | TV1, TV3 |
| Báo cáo kiểm tra bảo mật | 5, 10 | TV2 |
| Hướng dẫn deploy | 6 | TV2 |
| Kịch bản demo, Kịch bản kiểm thử | 7 | TV1 |
| So sánh cổng thanh toán | 8 | TV2 |
| Hình ảnh (ảnh chụp cho báo cáo, slide) | 2–11 | Cả nhóm |
